
// 1)using <> syntax -->angle bracket
var a:any="Hello";
console.log("before type assertion a : " +a);
var temp=<number> a;
temp=7777;
console.log("after type assertion a : " +temp)

// 2)using as keyword

var b:any=132;
console.log("before type assertion b : " +b);
var temp1=b as string;
temp1="Good Morning!";
console.log("after type asserion b : " +temp1);