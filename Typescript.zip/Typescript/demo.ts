

console.log("Hello! Good Morning");