var arr1 = [1, 2, 3, 4];
var arr2 = ["Red", "Orange", "Black", "Blue"];
var arr3 = [true, false];
var arr4 = ["Tejaswini", 7, true];
// push
console.log("using push method: " + arr1.push(7));
console.log(arr1);
// pop
console.log(arr2.pop());
console.log("using pop method" + arr2);
// splice
// To add the elements
arr2.splice(1, 0, "SkyBlue", "Yellow");
console.log("using splice method to add the element: " + arr2);
// To remove the elements
arr2.splice(2, 2);
console.log("using splice method to remove the element : " + arr2);
// To add and remove
arr2.splice(1, 1, "Peach", "Green", "Purple");
console.log("using splice method to add and remove the element : " + arr2);
// join
console.log(arr2.join(' '));
console.log(arr2.join('$'));
// slice
console.log(arr1.slice(1, 3));
