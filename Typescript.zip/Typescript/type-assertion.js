// 1)using <> syntax -->angle bracket
var a = "Hello";
console.log("before type assertion a : " + a);
var temp = a;
temp = 7777;
console.log("after type assertion a : " + temp);
// 2)using as keyword
var b = 132;
console.log("before type assertion b : " + b);
var temp1 = b;
temp1 = "Good Morning!";
console.log("after type asserion b : " + temp1);
