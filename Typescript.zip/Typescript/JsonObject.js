// object
var myObj = {
    id: 1,
    name: "bnm"
};
console.log(myObj.id);
// array of object
var arrObj = [
    {
        id: 1,
        name: "bnm"
    },
    {
        id: 2,
        name: "CVB"
    },
    {
        id: 3,
        name: "tyu"
    }
];
// Industry style JSON object
var jsonOBJ = {
    status: 'success',
    data: [
        {
            id: 101,
            name: 'Angular'
        },
        {
            id: 102,
            name: 'MongoDB'
        }
    ],
    error: 'not able to get the details'
};
var temp1 = jsonOBJ.status;
console.log('Message is :' + temp1);
if (temp1 == 'success') {
    console.log('--- in if---');
    console.log('data is: ' + jsonOBJ.data[0].name);
    console.log('data is: ' + jsonOBJ.data[1].name);
    // using for loop
    for (var i = 0; i < jsonOBJ.data.length; i++) {
        console.log('Details are : ' + jsonOBJ.data[i].name + ' ' + jsonOBJ.data[i].id);
    }
}
