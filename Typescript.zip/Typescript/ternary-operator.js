var x = 10;
var y = 13;
x > y ? console.log("x is greater than y") : console.log("x is less than y");
