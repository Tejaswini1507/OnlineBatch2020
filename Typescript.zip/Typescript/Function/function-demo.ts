
// Default Parameter function
function add(a:number, b:number=12){
    return a+b;
}
console.log("addition is : " +add(5));
// console.log("addition is : " +add(5,10));

// Optional Parameter Function
function mul(x:number, y?:number){
    return x*y;
}
console.log("Multiplication is---- : " +mul(7,7));

function mul1(x:number, y?:number, z?:number,){
    return x*y*z;
}
console.log("Multiplication is---- : " +mul(7,7));

// Rest Paramter Function


function greeting(a1:string, ...b1:any[]){
    return a1+b1;
}
console.log("Rest Paramter Function : " 
+greeting("React.js","Angular","Vue.js","nodeJs",true,7));

// rest paramter function -->wrong way
// function greeting1(...a1:string[], b1:any){
//     return a1+b1;
// }
// console.log("Rest Paramter Function : " 
// +greeting("React.js","Angular","Vue.js","nodeJs",true,7));

// Anonymous Function
var temp=function(){
    console.log("Anonymous function is working!!!!");
}
temp();
// alias

// Fat arrow function
function showMsg(){
    console.log("hey! I am working !!");
}
showMsg();


// var displayMsg=()=>{
//     console.log("Fat Arrow function is working!!!!");
// }
// displayMsg();

var displayMsg=()=>console.log("Fat Arrow function is working!!!!");
displayMsg();

