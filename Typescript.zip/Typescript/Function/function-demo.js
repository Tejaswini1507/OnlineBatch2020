// Default Parameter function
function add(a, b) {
    if (b === void 0) { b = 12; }
    return a + b;
}
console.log("addition is : " + add(5));
// console.log("addition is : " +add(5,10));
// Optional Parameter Function
function mul(x, y) {
    return x * y;
}
console.log("Multiplication is---- : " + mul(7, 7));
function mul1(x, y, z) {
    return x * y * z;
}
console.log("Multiplication is---- : " + mul(7, 7));
// Rest Paramter Function
function greeting(a1) {
    var b1 = [];
    for (var _i = 1; _i < arguments.length; _i++) {
        b1[_i - 1] = arguments[_i];
    }
    return a1 + b1;
}
console.log("Rest Paramter Function : "
    + greeting("React.js", "Angular", "Vue.js", "nodeJs"));
// Anonymous Function
var temp = function () {
    console.log("Anonymous function is working!!!!");
};
temp();
// alias
// Fat arrow function
function showMsg() {
    console.log("hey! I am working !!");
}
showMsg();
// var displayMsg=()=>{
//     console.log("Fat Arrow function is working!!!!");
// }
// displayMsg();
var displayMsg = function () { return console.log("Fat Arrow function is working!!!!"); };
displayMsg();
