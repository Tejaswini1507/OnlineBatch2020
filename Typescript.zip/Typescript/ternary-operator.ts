

var x:number=10;
var y:number=13;

x>y ? console.log("x is greater than y") : console.log("x is less than y");