// string
// number
// boolean
// any
// var
// let
var name1 = "Hefshine Softwares";
// name1=77;
console.log(name1);
var myNum = 7;
console.log(myNum);
var myData = "Teju";
myData = 77;
myData = true;
console.log(myData);
