import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-demo2',
  template: `
  <h1> by using template..
  </h1>
  `,
  styles: [`
  h1{
    color:orangered;
  }
  `]
})
export class Demo2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
