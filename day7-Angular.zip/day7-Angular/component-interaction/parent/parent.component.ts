import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.css']
})
export class ParentComponent implements OnInit {
  // string
  strMsg:string="Hefshine PVT LTD";

  // object
  user={
    id:1,
    name:"Tejaswini"
  }

  // Array of object
  playersInfo=[
    {
      name:"MSD",
      JRNumber:7,
      highestODIScore:183
    },
    {
      name:"Rohit Sharma",
      JRNumber:45,
      highestODIScore:264
    },
    {
      name:"Virat Kohli",
      JRNumber:18,
      highestODIScore:183
    }
  ]
  
  constructor() { }

  ngOnInit() {
  }

}
