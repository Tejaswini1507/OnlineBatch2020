import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'mypipe'
})
export class MypipePipe implements PipeTransform {

  transform(value: any): any {

    let currentYear=new Date().getFullYear();
    let empBirthYear=new Date(value).getFullYear();
    let userAge=currentYear-empBirthYear;
    console.log(userAge);
    return userAge;

    
  }

}



