import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-emp-list',
  templateUrl: './emp-list.component.html',
  styleUrls: ['./emp-list.component.css']
})
export class EmpListComponent implements OnInit {
  employee=[
    {
      id:101,
      name:"John",
      city:"Delhi",
      salary:20000,
      dob:new Date("8/7/1997"),
    },
    {
      id:102,
      name:"John",
      city:"Pune",
      salary:70000,
      dob:new Date("7/15/1994"),
    },
    {
      id:103,
      name:"John",
      city:"Mumbai",
      salary:80000,
      dob:new Date("4/18/1995"),
    },
    {
      id:104,
      name:"Sam",
      city:"Mumbai",
      salary:50000,
      dob:new Date("12/18/1994"),
    }
  ]
  constructor() { }

  ngOnInit() {
  }

}
