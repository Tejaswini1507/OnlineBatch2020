import { Component, OnInit } from '@angular/core';
import { EmpService } from '../emp.service';

@Component({
  selector: 'app-emp-data',
  templateUrl: './emp-data.component.html',
  styleUrls: ['./emp-data.component.css']
})
export class EmpDataComponent implements OnInit {
  employee=[];
  constructor(private empService:EmpService) { }

  ngOnInit() {
  this.employee=this.empService.getAllEmpDetails();
  }

}
