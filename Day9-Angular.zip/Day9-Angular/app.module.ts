import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule, routingcomponent } from './app-routing.module';
import { AppComponent } from './app.component';
import { Parent1Component } from './Component-interaction1/parent1/parent1.component';
import { Child1Component } from './Component-interaction1/child1/child1.component';
import { PipedemoComponent } from './pipedemo/pipedemo.component';
import { AgePipe } from './age.pipe';
import { EmpDetailsComponent } from './emp-details/emp-details.component';
import { MypipePipe } from './Custom-pipe-demo/mypipe.pipe';
import { EmpListComponent } from './Custom-pipe-demo/emp-list/emp-list.component';
import { EmpDataComponent } from './Srervice-demo/emp-data/emp-data.component';
import { EmpService } from './Srervice-demo/emp.service';

@NgModule({
  declarations: [
    AppComponent,
    routingcomponent,
    Parent1Component,
    Child1Component,
    PipedemoComponent,
    AgePipe,
    EmpDetailsComponent,
    MypipePipe,
    EmpListComponent,
    EmpDataComponent,
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [EmpService],
  bootstrap: [AppComponent]
})
export class AppModule { }
