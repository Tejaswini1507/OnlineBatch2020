import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-back-end',
  templateUrl: './back-end.component.html',
  styleUrls: ['./back-end.component.css']
})
export class BackEndComponent implements OnInit {
  backEnd:any[]=["Python", "Java"]
  constructor() { }

  ngOnInit() {
  }

}
