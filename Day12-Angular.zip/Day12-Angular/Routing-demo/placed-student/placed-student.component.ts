import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-placed-student',
  templateUrl: './placed-student.component.html',
  styleUrls: ['./placed-student.component.css']
})
export class PlacedStudentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
