import { Component, OnInit } from '@angular/core';
import { HttpDemoService } from '../http-demo.service';

@Component({
  selector: 'app-http-demo',
  templateUrl: './http-demo.component.html',
  styleUrls: ['./http-demo.component.css']
})
export class HttpDemoComponent implements OnInit {
  users=[];

  // to update the data
  myId;
  myTitle;
  myBody;
  isHidden:boolean=true;
  constructor(private httpDemoService:HttpDemoService) { }

  ngOnInit() {
    this.httpDemoService.getData()
    .subscribe(response=>{
      console.log(response.json());
      this.users=response.json();
    })
  }
  onAddData(title1,body1){
    let addObj={
      title:title1,    
      body:body1
    }
    this.httpDemoService.addData(addObj)
    .subscribe(value=>{
      console.log(value.json());
    })
  }
  onUpdateButton(item){
    this.isHidden=false;
    this.myId=item.id;
    this.myTitle=item.title;
    this.myBody=item.body;
  }
  onSubmitData(){
    let updateObj={
      id:this.myId,
      title:this.myTitle,
      body:this.myBody
    }
    this.httpDemoService.updateData(updateObj)
    .subscribe(value1=>{
      console.log(value1.json());
    })
  }
  onDeleteData(deleteObj){
      this.httpDemoService.doDeleteData(deleteObj)
      .subscribe(value2=>{
        console.log(value2.json());
        let id=value2.json().id;
        this.users.splice(id,1);
      })
    }
}
