import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pipedemo',
  templateUrl: './pipedemo.component.html',
  styleUrls: ['./pipedemo.component.css']
})
export class PipedemoComponent implements OnInit {

  myMsg:string="hefSHine";

  person={
    id:1,
    name:"xyz"
  }
  date= new Date();
  constructor() { }

  ngOnInit() {
  }

}
