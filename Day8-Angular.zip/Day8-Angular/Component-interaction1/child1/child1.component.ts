import { Component, EventEmitter, OnInit, Output } from '@angular/core';


@Component({
  selector: 'app-child1',
  templateUrl: './child1.component.html',
  styleUrls: ['./child1.component.css']
})
export class Child1Component implements OnInit {

  @Output() childToParentStr=new EventEmitter();
  myMsg:string="Hefshine Pvt Ltd";

  @Output() childToParentObj=new EventEmitter();
  // object
  user={
    id:1,
    name:"Tejaswini"
  }

  @Output() childToParentArrObj=new EventEmitter();
 ///Arrray of object 
  personDetails=[
    {
      id:1,
      name:"Tejaswini"
    },
    {
      id:2,
      name:"lmn"
    },
    {
      id:3,
      name:"pqr"
    }
  ]
  constructor() { }

  ngOnInit() {
  }
  onClick(){
    console.log("hello!");
    this.childToParentStr.emit(this.myMsg);
  }
  onClickObj(){
    this.childToParentObj.emit(this.user);
  }
  onClickArrObj(){
    this.childToParentArrObj.emit(this.personDetails);
  }
}