import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-class-binding',
  templateUrl: './class-binding.component.html',
  styleUrls: ['./class-binding.component.css']
})
export class ClassBindingComponent implements OnInit {

  // class binding
  myclass1:string="styleClass";
  isDanger:boolean=false;
  isStyle:boolean=false;

  msgClass={
    "text-go":!this.isDanger,
    "text-stop":this.isDanger,
    "styleClass":this.isStyle
  }
  constructor() { }

  ngOnInit() {
  }

}
