import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ng-for-directive',
  templateUrl: './ng-for-directive.component.html',
  styleUrls: ['./ng-for-directive.component.css']
})
export class NgForDirectiveComponent implements OnInit {

  // Array
  course:any[]=["java","Angular","Advance Java","MYSQL"];

  // Array of object
  playersInfo=[
    {
      name:"MSD",
      JRNumber:7,
      highestODIScore:183
    },
    {
      name:"Rohit Sharma",
      JRNumber:45,
      highestODIScore:264
    },
    {
      name:"Virat Kohli",
      JRNumber:18,
      highestODIScore:183
    }
  ]

  constructor() { }

  ngOnInit() {
  }

}
