import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import {FormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DemoComponent } from './demo/demo.component';
import { Demo2Component } from './demo2/demo2.component';
import { DataBindingComponent } from './data-binding/data-binding.component';
import { ClassBindingComponent } from './class-binding/class-binding.component';
import { StyleBindingComponent } from './style-binding/style-binding.component';
import { TwoWayBindingComponent } from './two-way-binding/two-way-binding.component';
import { Day6Component } from './day6/day6.component';
import { TestComponent } from './test/test.component';
import { TrvComponent } from './trv/trv.component';
import { NgIfDirectiveComponent } from './ng-if-directive/ng-if-directive.component';
import { NgForDirectiveComponent } from './ng-for-directive/ng-for-directive.component';
import { NgSwitchDirectiveComponent } from './ng-switch-directive/ng-switch-directive.component';


@NgModule({
  declarations: [
    AppComponent,

    
    DemoComponent,
    Demo2Component,
    DataBindingComponent,
    ClassBindingComponent,
    StyleBindingComponent,
    TwoWayBindingComponent,
    Day6Component,
    TestComponent,
    TrvComponent,
    NgIfDirectiveComponent,
    NgForDirectiveComponent,
    NgSwitchDirectiveComponent
  ],
  
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
