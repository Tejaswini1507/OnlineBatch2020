import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ng-if-directive',
  templateUrl: './ng-if-directive.component.html',
  styleUrls: ['./ng-if-directive.component.css']
})
export class NgIfDirectiveComponent implements OnInit {
  // if part
  rating1:number=7;

  // if-else
  rating2:number=14;

  // if-else-then
  rating3:number=19;

  constructor() { }

  ngOnInit() {
  }

}
