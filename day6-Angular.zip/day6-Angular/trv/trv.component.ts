import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-trv',
  template: `
   <input type="text" #myInput>
   <br> <br>
   <button (click)="onClick(myInput.value)">Display</button>
   <p>{{myname}}</p>
   <br> <br>
   <label>username:
   <input type="text" #uname>
   <br> <br>
   <label>password:
   <input type="password" #pwd>
   <br> <br>
   <button (click)="onUserLogin(uname.value,pwd.value)">Login</button>
   <p>{{msg1}}</p>
  `,
  styles: []
})
export class TrvComponent implements OnInit {
  myname:any=" ";
  msg1:string=" ";
   
  constructor() { }

  ngOnInit() {
  }
  onClick(name){
    console.log(name);
    this.myname=name
  }
  onUserLogin(uname,pwd){
    if(uname==="admin" && pwd==="admin"){
      console.log("login successfully");
      this.msg1="login successfully";
    }else{
      console.log("data is not valid!");
      this.msg1="data is not valid!";
    }
  }
}
