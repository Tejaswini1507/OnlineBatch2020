import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bootstrap-demo',
  templateUrl: './bootstrap-demo.component.html',
  styleUrls: ['./bootstrap-demo.component.css']
})
export class BootstrapDemoComponent implements OnInit {
  playersInfo=[
    {
      name:"MSD",
      JRNumber:7,
      highestODIScore:183
    },
    {
      name:"Rohit Sharma",
      JRNumber:45,
      highestODIScore:264
    },
    {
      name:"Virat Kohli",
      JRNumber:18,
      highestODIScore:183
    }
  ]
  constructor() { }

  ngOnInit() {
  }

}
