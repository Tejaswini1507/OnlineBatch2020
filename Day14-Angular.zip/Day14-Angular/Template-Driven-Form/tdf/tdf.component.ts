import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tdf',
  templateUrl: './tdf.component.html',
  styleUrls: ['./tdf.component.css']
})
export class TdfComponent implements OnInit {

  contactMethod=[
    {
      id:1,name:'Email'
    },
    {
      id:2, name:'Phone'
    },
    {
      id:3, name:'Twitter'
    },
    {
      id:4, name:'Facebook'
    },
    {
      id:5, name:'Instagram'
    }
  ]
  constructor() { }

  ngOnInit() {
  }

}
