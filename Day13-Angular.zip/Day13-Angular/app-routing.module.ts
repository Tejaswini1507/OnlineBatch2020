import { QueryParamComponent } from './Routing-demo/query-param/query-param.component';
import { BackEndComponent } from './Routing-demo/back-end/back-end.component';
import { FrontEndComponent } from './Routing-demo/front-end/front-end.component';
import { HomeComponent } from './Routing-demo/home/home.component';
import { ErrorComponent } from './Routing-demo/error/error.component';
import { StudentFeedbackComponent } from './Routing-demo/student-feedback/student-feedback.component';
import { PlacedStudentComponent } from './Routing-demo/placed-student/placed-student.component';
import { TechnologyComponent } from './Routing-demo/technology/technology.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  {
    path:'', component:HomeComponent
  },
  {
    path:'technology', 
    component:TechnologyComponent,
   children:[
    {
      path:'frontend' , component:FrontEndComponent
    },
    {
      path:'backend', component:BackEndComponent
    },
   ]
  },
  {
    path:'placedStudent/:id' , component:PlacedStudentComponent
  },
  {
    path:'studentFeedBack', component:StudentFeedbackComponent
  },
  {
    path:'queryParam', component:QueryParamComponent
  },
  {
    path:'**', component:ErrorComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const AppRoutingComponent=[
  HomeComponent,
  TechnologyComponent,
  FrontEndComponent,
  BackEndComponent,
  PlacedStudentComponent,
  StudentFeedbackComponent,
  QueryParamComponent,
  ErrorComponent

]
