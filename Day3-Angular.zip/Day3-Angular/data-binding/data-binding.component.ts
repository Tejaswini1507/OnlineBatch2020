import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-data-binding',
  templateUrl: './data-binding.component.html',
  styleUrls: ['./data-binding.component.css']
})
export class DataBindingComponent implements OnInit {
// string interpolation
  text1:string='string interpolation works!';
  
// *Note-->text1 and text2 is property here
// if we didn't give data type for them 
// then it will not throw 
// any error. It will recognize it's data type
//  but for better
// practice you must mention it's data type.

// Property Binding
  text2:string='Property Binding Works!';


  // difference pr binding and string interpolation
  isHidden:boolean=false;
  isHidden1:boolean=false;

  // event binding
  count:number=0;
  showMsg:string=" ";
  dispText:string="Event Binding";
  isHidden2:boolean=true;
  name:string=" ";
  msg1:string=" ";
  constructor() { }

  ngOnInit() {
  }

  // event binding
  onClick(){
    if(this.count===0)
    console.log("Event Binding Works!");
    this.count=this.count+1;
  }
  onDisplayMsg(){
    this.showMsg="Hefshine Softwares";
  }
  onDisplayText(){
    this.isHidden2=false;
  }
  onBtnClick(){
    this.name="Angular";
  }
  onShow(myevent){
    console.log(myevent);
    this.msg1=myevent.type;
  }
}
