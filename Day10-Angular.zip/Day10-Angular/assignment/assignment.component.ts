import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-assignment',
  templateUrl: './assignment.component.html',
  styleUrls: ['./assignment.component.css']
})
export class AssignmentComponent implements OnInit {
  // onChange
  myColor:string="white";

  // onclick of btn using style binding
  mycolor1:string=" ";

  // onclick of btn using class binding
  myClass=" ";
  constructor() { }

  ngOnInit() {
  }
  onChange(){
    console.log("event is occured!!!");
    this.myColor="red";
  }
  // style binding
  onClick(){
    this.mycolor1="red";
  }
  // class binding
  onBtnClick(){
    console.log("event is occured!!");
    this.myClass="mybtn";
    
  }
  
  // ngIf -->even or odd
  myNum:number=10;
  myNum1:number=11;
}
