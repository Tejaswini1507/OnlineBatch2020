import { Injectable } from '@angular/core';
import { Http } from '@angular/http';

@Injectable({
  providedIn: 'root'
})
export class HttpDemoService {

  constructor(private http:Http) { }
  url:string="https://jsonplaceholder.typicode.com/posts";


  getData(){   
    return this.http.get(this.url);
  }
  addData(addObj){
    return this.http.post(this.url,JSON.stringify(addObj))
  }
}
