import { Component, OnInit } from '@angular/core';
import { HttpDemoService } from '../http-demo.service';

@Component({
  selector: 'app-http-demo',
  templateUrl: './http-demo.component.html',
  styleUrls: ['./http-demo.component.css']
})
export class HttpDemoComponent implements OnInit {
  users=[];
  constructor(private httpDemoService:HttpDemoService) { }

  ngOnInit() {
    this.httpDemoService.getData()
    .subscribe(response=>{
      console.log(response.json());
      this.users=response.json();
    })
  }
  onAddData(title1,body1){
    let addObj={
      title:title1,
      body:body1
    }
    this.httpDemoService.addData(addObj)
    .subscribe(value=>{
      console.log(value.json());
    })
  }
}
