import { TestBed } from '@angular/core/testing';

import { HttpDemoService } from './http-demo.service';

describe('HttpDemoService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: HttpDemoService = TestBed.get(HttpDemoService);
    expect(service).toBeTruthy();
  });
});
